
package modelo;

/**
 *
 * @author sergio
 */
public class MetodosConFicheros {
    
    public void guardarPartida(){
        
        
    }
    
    public void estadisticasPartida(){
        
        
    }
}
