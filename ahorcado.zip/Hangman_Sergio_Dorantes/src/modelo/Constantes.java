
package modelo;

/**
 *
 * @author Sergio Dorantes Godino
 *
 */
public class Constantes {

    public static final String SOLICITAR_NOMBRE = "Escribe tu nombre de usuario";
    public static final String SOLICITAR_CONTRASENA = "Escribe una contraseña";
    public static final String USUARIO_NO_VALIDO = "El usuario/contraseña no son válidos, por favor pruebe con un usuario/contraseña válidos.";
    public static final String ANONIMO = "OK crack, jugarás como anónimo";
    public static final String OPCION_INCORRECTA = "OPCION INCORRECTA";
    
}
