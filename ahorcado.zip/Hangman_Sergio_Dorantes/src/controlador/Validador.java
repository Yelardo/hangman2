package controlador;

import java.util.regex.Pattern;

/*public class Validador {
    public static boolean validarNombre(String entrada){
        //Patron que combina que tenga que tener un numero obligatoriamente y que sea alfanumerico y empiece por letra
        Pattern patron = Pattern.compile("^(?=.*[0-9])(?=[a-zA-Z])[a-zA-Z0-9]{4}$");
        return patron.matcher(entrada).matches();
    }
}*/